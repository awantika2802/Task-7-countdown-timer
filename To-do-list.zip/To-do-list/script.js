document.addEventListener('DOMContentLoaded', function() {
    loadTasksFromLocalStorage();
  });
  
  function addTask() {
    const input = document.getElementById('task-input');
    const task = input.value.trim();
  
    if (task === '') {
      alert('Please enter a task.');
      return;
    }
  
    const taskList = document.getElementById('task-list');
    const li = document.createElement('li');
    li.innerHTML = ${task} <span class="delete-button" onclick="deleteTask(this)">❌</span>;
    taskList.appendChild(li);
  
    saveTaskToLocalStorage(task);
  
    input.value = '';
  }
  
  function deleteTask(element) {
    const taskText = element.parentElement.textContent.trim();
    element.parentElement.remove();
    removeTaskFromLocalStorage(taskText);
  }
  
  function saveTaskToLocalStorage(task) {
    let tasks = localStorage.getItem('tasks');
  
    if (tasks === null) {
      tasks = [];
    } else {
      tasks = JSON.parse(tasks);
    }
  
    tasks.push(task);
    localStorage.setItem('tasks', JSON.stringify(tasks));
  }
  
  function removeTaskFromLocalStorage(task) {
    let tasks = localStorage.getItem('tasks');
  
    if (tasks === null) {
      return;
    }
  
    tasks = JSON.parse(tasks);
    tasks = tasks.filter(item => item !== task);
    localStorage.setItem('tasks', JSON.stringify(tasks));
  }
  
  function loadTasksFromLocalStorage() {
    let tasks = localStorage.getItem('tasks');
  
    if (tasks === null) {
      return;
    }
  
    tasks = JSON.parse(tasks);
    const taskList = document.getElementById('task-list');
  
    tasks.forEach(task => {
      const li = document.createElement('li');
      li.innerHTML = ${task} <span class="delete-button" onclick="deleteTask(this)">❌</span>;
      taskList.appendChild(li);
    });
  }